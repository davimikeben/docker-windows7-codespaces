# 🪟 Windows 7 em Docker + GitHub Codespaces

[![Abrir no GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/davimikeben/windows-7-codespaces?quickstart=1)
[![Docker](https://img.shields.io/badge/docker-%230db7ed.svg?style=flat&logo=docker&logoColor=white)](https://www.docker.com/)
[![Licença: MIT](https://img.shields.io/badge/licen%C3%A7a-MIT-green.svg)](LICENSE)
[![Base: dockur/windows](https://img.shields.io/badge/base-dockur%2Fwindows-blue.svg)](https://github.com/dockur/windows)

> **Suba um Windows 7 Ultimate SP1 (x64) automatizado dentro de um container Docker** — com 1 clique no GitHub Codespaces ou localmente com Docker — e acesse pelo navegador (porta `8006`) ou via RDP (porta `3389`). Tudo em português (PT-BR), teclado ABNT2 e fuso `America/Sao_Paulo`.

> ⚠️ **Avisos importantes**
> - O **Windows 7 chegou ao fim do suporte em janeiro de 2020**: não recebe atualizações de segurança. Use para **estudos, testes de software legado e compatibilidade** — não para dados sensíveis, banco ou navegação do dia a dia.
> - Este repositório contém **apenas código aberto** e baixa a imagem durante a instalação. **Você é responsável por ter uma licença válida do Windows** e cumprir os termos da Microsoft. As chaves genéricas usadas na instalação automática servem só para avaliação (trial).
> - A primeira instalação **baixa ~3 GB e pode levar de 15 a 60 minutos** (dependendo da máquina/Codespaces).

---

## ✨ O que este repositório faz

- 🐳 **Container pronto** baseado no projeto [dockur/windows](https://github.com/dockur/windows) (QEMU + KVM) com `VERSION: "7u"` (Windows 7 Ultimate).
- ☁️ **1 clique no Codespaces**: [devcontainer](.devcontainer/devcontainer.json) + compose otimizados para o ambiente do GitHub.
- 💻 **Uso local**: `compose.yml` com KVM para performance quase nativa no Linux.
- 🇧🇷 **PT-BR por padrão**: idioma `Portuguese`, região/teclado `pt-BR`, fuso `America/Sao_Paulo`.
- 🔌 **Acesso fácil**: visualizador web na porta `8006` + RDP na `3389` (usuário `Docker` / senha `admin`).
- 📁 **Integração com o host**: pasta compartilhada (vira o drive `Z:`) e pasta `oem/` para rodar um `install.bat` automático.
- 🧰 **Scripts utilitários** em `scripts/`: checar KVM, subir local/Codespaces, resetar a instalação.
- ✅ **CI no GitHub Actions**: valida o compose, o devcontainer e os scripts a cada push.

### 🧱 Arquitetura

```text
┌─────────────────────────────────────────────────────────┐
│  GitHub Codespaces (ou seu Linux local com Docker)      │
│                                                         │
│  ┌────────────────── container: win7 ─────────────────┐ │
│  │  dockurr/windows (QEMU + KVM quando disponível)    │ │
│  │  • Instalação automática do Win7 Ultimate SP1 x64  │ │
│  │  • Web viewer :8006  •  RDP :3389                  │ │
│  │  • /storage (disco virtual)  •  /shared (drive Z:) │ │
│  │  • /oem (install.bat pós-instalação)               │ │
│  └───────────────────────────────────────────────────┘ │
│   volumes no host: ./windows  ./shared  ./oem           │
└─────────────────────────────────────────────────────────┘
        │ navegador → porta 8006        │ RDP → porta 3389
        ▼                               ▼
     seu browser              app de Área de Trabalho Remota
```

---

## 🚀 Comece em 1 clique (GitHub Codespaces)

1. **Publique este projeto no seu GitHub** (veja [📤 Publicando no GitHub](#-publicando-no-github)).
2. **Troque `davimikeben`** no botão do topo deste README pelo seu usuário/organização:
   `https://codespaces.new/davimikeben/windows-7-codespaces?quickstart=1`
3. Clique em **Open in GitHub Codespaces** (ou acesse a URL acima).
   - Recomendado: máquina com **4 núcleos / 8 GB RAM / 32 GB de disco** (o plano gratuito costuma atender; confira sua cota de Codespaces).
4. Aguarde o container subir. Na aba **PORTAS**, abra a porta **`8006`** no navegador.
5. Acompanhe a instalação automática até aparecer a área de trabalho do Windows 7. ☕

> 💡 Detalhes de RDP no Codespaces, custos/cotas e solução de problemas: veja [docs/GUIA-RAPIDO.md](docs/GUIA-RAPIDO.md) e [docs/FAQ.md](docs/FAQ.md).

---

## 💻 Uso local (Docker no Linux)

**Pré-requisitos:** Linux 64 bits com KVM habilitado (ou Windows 11/WSL2 com virtualização aninhada), Docker 24+, ~4 GB de RAM livre e ~35 GB de disco.

```bash
# 1. Clonar
git clone https://github.com/davimikeben/windows-7-codespaces.git
cd windows-7-codespaces

# 2. Configurar variáveis (opcional, já há padrões PT-BR)
cp .env.example .env
nano .env   # ajuste RAM, CPU, disco, senha...

# 3. Verificar KVM e Docker
./scripts/check-kvm.sh

# 4. Subir o container
docker compose up -d

# 5. Acompanhar os logs (opcional)
docker compose logs -f windows
```

Depois abra **http://localhost:8006** e aguarde a instalação automática (10–40 min na primeira vez).

| Ação | Comando |
|---|---|
| Ver status | `docker compose ps` |
| Ver logs | `docker compose logs -f windows` |
| Parar | `docker compose stop` |
| Parar + remover container (mantém o disco) | `docker compose down` |
| **Apagar tudo e reinstalar do zero** | `./scripts/reset.sh` |

---

## ⚙️ Configuração (arquivo `.env`)

Copie `.env.example` para `.env` e ajuste antes da **primeira** instalação:

| Variável | Padrão | Descrição |
|---|---|---|
| `VERSION` | `7u` | Versão do Windows (`7u` = Win7 Ultimate). Outras: `10`, `11`, `xp`… ([lista](https://github.com/dockur/windows)) |
| `LANGUAGE` | `Portuguese` | Idioma da instalação |
| `REGION` / `KEYBOARD` | `pt-BR` | Região e layout do teclado (ABNT2) |
| `RAM_SIZE` | `4G` | RAM da VM (mín. `2G`) |
| `CPU_CORES` | `2` | Núcleos de CPU da VM |
| `DISK_SIZE` | `30G` | Tamanho do disco virtual |
| `USERNAME` / `PASSWORD` | `Docker` / `admin` | Usuário e senha criados na instalação |
| `AUDIO` | `Y` | Áudio no navegador (ative também em *Settings → Advanced* no viewer) |
| `TZ` | `America/Sao_Paulo` | Fuso horário do container |

> ⚠️ `USERNAME`, `PASSWORD`, `LANGUAGE` e `VERSION` só valem para uma **instalação nova**. Para trocar depois, altere dentro do próprio Windows (ou rode `./scripts/reset.sh` e reinstale).

---

## 🔌 Acessos

| Acesso | Onde | Credenciais / obs. |
|---|---|---|
| 🌐 **Navegador (web viewer)** | `http://localhost:8006` (local) ou porta `8006` encaminhada (Codespaces) | Ideal para acompanhar a instalação |
| 🔌 **RDP** | `localhost:3389` (local) ou porta `3389` encaminhada (Codespaces, visibilidade **pública**) | Usuário `Docker` · senha `admin` — use o app *Área de Trabalho Remota* (`mstsc`), FreeRDP ou app mobile |
| 📁 **Pasta compartilhada** | Arquivos de `./shared/` → área de trabalho (`Shared`) e **drive `Z:`** | Troque arquivos entre host e VM |
| 🧩 **Pós-instalação** | `./oem/install.bat` → copiado para `C:\OEM` e executado ao final do setup | Instale programas automaticamente |
| 💿 **ISO própria** | Descomente `- ./custom.iso:/custom.iso` no compose e coloque sua ISO com esse nome | `VERSION` é ignorado nesse modo |

---

## 📁 Estrutura do repositório

```text
windows-7-codespaces/
├── README.md                  # este guia
├── compose.yml                # compose principal (uso local, com KVM)
├── docker-compose.yml         # espelho do compose.yml (compatibilidade)
├── Dockerfile                 # imagem customizada (base dockurr/windows + padrões PT-BR)
├── .env.example               # variáveis de configuração (copie para .env)
├── .devcontainer/
│   ├── devcontainer.json      # config 1-clique do Codespaces
│   └── codespaces.yml         # compose otimizado para o Codespaces
├── scripts/
│   ├── check-kvm.sh           # verifica KVM, Docker, disco e RAM
│   ├── start-local.sh         # sobe o container localmente
│   ├── start-codespaces.sh    # sobe manualmente dentro do Codespace
│   └── reset.sh               # apaga o disco e reinstala do zero
├── oem/install.bat            # script pós-instalação (exemplo)
├── shared/                    # pasta compartilhada com a VM (drive Z:)
├── windows/                   # disco virtual e estado da VM (ignorado pelo git)
├── docs/
│   ├── GUIA-RAPIDO.md         # passo a passo detalhado
│   └── FAQ.md                 # perguntas frequentes
└── .github/workflows/         # CI: validação + publicação da imagem no GHCR
```

---

## 🩺 Solução rápida de problemas

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| Erro `/dev/kvm not found` | Host sem KVM | No Linux: habilite VT-x/AMD-V na BIOS e rode `sudo kvm-ok`. Sem KVM, comente as linhas `devices:` no compose (vai funcionar **bem mais lento**, por emulação) |
| Instalação muito lenta no Codespaces | Máquina pequena / emulação | Use máquina de 4 núcleos; primeira instalação sempre demora — aguarde |
| `no space left on device` | Disco cheio (imagem ~3 GB + disco 25–30 GB) | `docker system prune -a --volumes` (cuidado: apaga outros dados Docker) e use `DISK_SIZE` menor |
| Porta 8006 não abre | Container ainda instalando/baixando | Veja `docker compose logs -f windows` e aguarde; confira a aba **PORTAS** no Codespaces |
| RDP não conecta | Instalação não terminou / porta privada | Aguarde o desktop aparecer no viewer; no Codespaces deixe a porta `3389` **pública** |
| Esqueci a senha | — | Troque dentro do Windows (Painel de Controle → Contas) ou reinstale com `./scripts/reset.sh` |

Mais detalhes em [docs/FAQ.md](docs/FAQ.md).

---

## 📤 Publicando no GitHub

Com a CLI do GitHub instalada:

```bash
cd windows-7-codespaces
git init -b main
git add .
git commit -m "feat: Windows 7 em Docker + Codespaces 🇧🇷"
gh repo create windows-7-codespaces --public --source=. --push
```

Sem a CLI: crie um repositório vazio chamado `windows-7-codespaces` no GitHub pelo site e siga as instruções de push que ele mostra. (Os links deste README já apontam para `davimikeben` ✅)

Opcional — publicar sua imagem customizada no GHCR: crie uma tag e envie:

```bash
git tag v1.0.0 && git push origin v1.0.0
# o workflow "Publicar imagem no GHCR" compila o Dockerfile e publica em ghcr.io/davimikeben/windows-7-codespaces
```

---

## ⚖️ Legalidade e licenças

- Este projeto é **código aberto (MIT)** e **não redistribui o Windows**. A ISO é baixada no momento da instalação.
- **Você precisa de uma licença válida do Windows 7** para uso além de avaliação, conforme os [termos de licenciamento da Microsoft](https://www.microsoft.com/pt-br/licensing/).
- Windows 7 está **fora de suporte desde 14/01/2020**: sem correções de segurança. Use por sua conta e risco, preferencialmente isolado e para fins de teste/legado.

## 🙏 Créditos

- [dockur/windows](https://github.com/dockur/windows) — motor QEMU/KVM + instalação automática que torna tudo isso possível. ⭐ Considere apoiar o projeto original.
- Comunidade Docker, GitHub Codespaces e QEMU.

## 📄 Licença

[MIT](LICENSE) — faça fork, adapte e compartilhe. 🙂
