---
name: 🐞 Reportar problema
about: Algo não funcionou? Conte pra gente.
title: "[BUG] "
labels: bug
---

## 🖥️ Ambiente

- [ ] GitHub Codespaces (qual máquina? ex.: 4 núcleos / 8 GB)
- [ ] Docker local (qual SO? ex.: Ubuntu 24.04)
- [ ] Outro: ___

## 📝 O que aconteceu?

Descreva o problema e o que você esperava que acontecesse.

## 🔁 Como reproduzir

1.
2.
3.

## 📋 Logs relevantes

Cole aqui a saída de `docker compose logs windows` (ou `docker logs -f windows`):

```text
(cole os logs)
```

## ➕ Informações extras

Versão do Docker, prints de tela, alterações no `.env`, etc.
